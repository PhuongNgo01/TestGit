﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using BUS_QLBanHang;
using DTO_QLBanHang;
namespace TemplateProject1_QLBanHang
{
    public partial class FrmDangNhap : Form
    {
        //su dụng các thành phần từ BUS_NhanVien class
        BUS_NhanVien busNhanVien = new BUS_QLBanHang.BUS_NhanVien();

        //Các giá trị pass cho FrmMain phân quyền
        public string email { set; get; }
        public string matkhau { get; set; }
        public string vaitro { set; get; }//đang nhạp thành công, kiem tra vai tro
        public FrmDangNhap()
        {
            InitializeComponent();
        }

        private void SaveRememberedLogin()
        {
            if (checkBox1.Checked)
            {
                Properties.Settings.Default.Email = txtemail.Text;
                Properties.Settings.Default.Password = encryption(txtmatkhau.Text);
                Properties.Settings.Default.RememberMe = true;
            }
            else
            {
                Properties.Settings.Default.Email = "";
                Properties.Settings.Default.Password = "";
                Properties.Settings.Default.RememberMe = false;
            }
            Properties.Settings.Default.Save();
        }
        private void LoadRememberedLogin()
        {
            if (Properties.Settings.Default.RememberMe)
            {
                txtemail.Text = Properties.Settings.Default.Email;
                txtmatkhau.Text = Properties.Settings.Default.Password; // Hoặc giải mã nếu cần
                checkBox1.Checked = true;
            }
        }

        private void FrmDangNhap_Load(object sender, EventArgs e)
        {
            FrmMain.session = 0;// not yet login
            LoadRememberedLogin();
        }

        //event for thoat button
        private void Button3_Click(object sender, EventArgs e)// thoat
        {
            this.Close();
        }
        //Boolean login = false;//chưa đang nhap
        
        private void Btndangnhap_Click(object sender, EventArgs e)
        {
            DTO_NhanVien nv = new DTO_NhanVien();
            nv.EmailNV = txtemail.Text;
            nv.MatKhau = encryption(txtmatkhau.Text);// ma mat khau de so sanh voi mat khau da ma hoa trong csdl
            if (busNhanVien.NhanVienDangNhap(nv))//successfull login
            {
                //login = true;
                FrmMain.mail = nv.EmailNV; // truyen email dang nhap cho frmMain
                DataTable dt = busNhanVien.VaiTroNhanVien(nv.EmailNV);
                vaitro = dt.Rows[0][0].ToString();// lây vai tro cua nhan vien, hien thi cac chuc nang ma nhan vien co the thao tac
                MessageBox.Show("Đăng nhập thành công");
                FrmMain.session = 1; // cap nhat trang thai da dang nhap thanh cong
                SaveRememberedLogin(); // Lưu thông tin đăng nhập nếu checkbox được chọn
                this.Close();
            }
            else
            {
                MessageBox.Show("Đăng nhập không thành công, kiểm tra lại email hoặc mật khẩu");
                txtemail.Text = null;
                txtmatkhau.Text = null;
                txtemail.Focus();
            }
        }

        //ma hóa md5 password
        public string encryption(string password)
        {
            MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
            byte[] encrypt;
            UTF8Encoding encode = new UTF8Encoding();
            //encrypt the given password string into Encrypted data  
            encrypt = md5.ComputeHash(encode.GetBytes(password));
            StringBuilder encryptdata = new StringBuilder();
            //Create a new string by using the encrypted data  
            for (int i = 0; i < encrypt.Length; i++)
            {
                encryptdata.Append(encrypt[i].ToString());
            }
            return encryptdata.ToString();
        }

        //xu ly quen mat khau
        private void btnQuenmk_Click(object sender, EventArgs e)
        {
            // Kiểm tra nếu TextBox email không trống
            if (txtemail.Text != "")
            {
                // Kiểm tra xem email có tồn tại trong cơ sở dữ liệu không
                if (busNhanVien.NhanVienQuenMatKhau(txtemail.Text)) // Kiểm tra nếu email tồn tại
                {
                    // Tạo mật khẩu ngẫu nhiên
                    StringBuilder builder = new StringBuilder();
                    builder.Append(RandomString(4, true));  // Thêm 4 ký tự chữ cái
                    builder.Append(RandomNumber(1000, 9999)); // Thêm 4 số ngẫu nhiên
                    builder.Append(RandomString(2, false));  // Thêm 2 ký tự chữ số
                    string newPassword = builder.ToString(); // Mật khẩu mới

                    // Hiển thị mật khẩu mới (tùy chọn, có thể bỏ qua nếu không cần)
                    MessageBox.Show("Mật khẩu mới của bạn là: " + newPassword);

                    // Mã hóa mật khẩu mới để lưu vào cơ sở dữ liệu
                    string encryptedPassword = encryption(newPassword);

                    // Cập nhật mật khẩu mới vào cơ sở dữ liệu
                    busNhanVien.TaoMatKhau(txtemail.Text, encryptedPassword);

                    // Thông báo người dùng rằng mật khẩu đã được gửi
                    MessageBox.Show("Một email phục hồi mật khẩu đã được gửi đến bạn!");
                }
                else
                {
                    // Nếu email không tồn tại trong hệ thống
                    MessageBox.Show("Email không tồn tại, vui lòng nhập lại email!");
                }
            }
            else
            {
                // Nếu người dùng chưa nhập email
                MessageBox.Show("Bạn cần nhập email để nhận thông tin phục hồi mật khẩu!");
                txtemail.Focus();
            }
        }


        //Tao chuoi ngau nhien
        public string RandomString(int size, bool lowerCase)
        {
            StringBuilder builder = new StringBuilder();
            Random random = new Random();
            char ch;
            for (int i = 0; i < size; i++)
            {
                ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 65)));
                builder.Append(ch);
            }
            if (lowerCase)
                return builder.ToString().ToLower();
            return builder.ToString();
        }
        //Tao so ngau nhien
        public int RandomNumber(int min, int max)
        {
            Random random = new Random();
            return random.Next(min, max);
        }

        // send mail
        public void SendMail(string matkhau, string email)
        {

            // Kiểm tra xem email có trống không
            if (string.IsNullOrEmpty(email))
            {
                MessageBox.Show("Vui lòng nhập địa chỉ email.");
                return;
            }

            try
            {
                // Sử dụng máy chủ SMTP của Gmail với mật khẩu ứng dụng (App Password)
                SmtpClient client = new SmtpClient("smtp.gmail.com", 587); // Dùng cổng 587 cho TLS
                client.Credentials = new NetworkCredential("", ""); // Sử dụng mật khẩu ứng dụng thay vì mật khẩu thông thường.
                client.EnableSsl = true;

                // Tạo và thiết lập email
                MailMessage Msg = new MailMessage();
                Msg.From = new MailAddress("");
                Msg.To.Add(email); // Người nhận lấy từ TextBox
                Msg.Subject = "Bạn đã sử dụng tính năng quên mật khẩu";
                Msg.Body = "Chào bạn, mật khẩu mới để truy cập phần mềm là: " + matkhau;

                // Gửi email
                client.Send(Msg);
                MessageBox.Show("Một email phục hồi mật khẩu đã được gửi đến bạn!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi khi gửi email: " + ex.Message);
            }
        }



        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}

